from django.apps import AppConfig


class As2Config(AppConfig):
    name = 'as2'
